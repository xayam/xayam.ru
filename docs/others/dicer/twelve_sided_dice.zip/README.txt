Twelve sided dice - lose twice as much money in half the time! by reactron on Thingiverse: https://www.thingiverse.com/thing:2870203

Summary:
A very nice, quick tutorial on modeling a dodecahedron in Fusion 360 is here :https://www.youtube.com/watch?v=O8AfCReT3Kg&amp;ab_channel=EtienneE
