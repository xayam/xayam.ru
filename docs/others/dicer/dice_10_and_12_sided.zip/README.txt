Dice - 10 and 12 sided by makeplace on Thingiverse: https://www.thingiverse.com/thing:38156

Summary:
These are not the dice that you are looking for...Aahh..All right..Maybe they are..Yes ok they are.. I confess..They have 10 and 12 sides respectively.To be exact..
